# CrashCart offline regression

Mode: RECORDED_REPLAY. Source mode: LIVE_SANDBOX.
Python 3.11+ and its standard library only. No credentials, installation, or network access are needed.

Run from the extracted folder:

    python3 -m crashcart.replay verify-manifest .
    python3 -m crashcart.replay run input.json --merchant defective
    python3 -m crashcart.replay run input.json --merchant healthy
    python3 -m crashcart.replay reduce input.json --budget 16 --repeats 3

Exit codes: PASS=0, invariant FAIL=1, INCONCLUSIVE=2, invalid package=3.
The defective regression must fail specifically with paid_without_ticket. The healthy variant uses the SAME input, clock, fault and invariant; it passes only if recorded reconciliation occurs within 60 seconds.
A new SQLite namespace re-executes Store confirmation/fulfillment and the invariant. Saved verdicts are not inputs. Process interruption is simulated by reopening persisted Store state, not killing an OS process.
This artifact makes no fresh-sandbox claim. Source labels/hashes do not authenticate the original observations. A fresh sandbox run requires new approval and provider evidence outside this offline program. Browser recordings are external original evidence; this package carries sanitized observations, not a fabricated recording.
